import{j as s,h as t}from"./index-uqXiPZaM.js";import"./vendor-DTs43g_X.js";const e=()=>s.jsx(t,{title:"Dashboard",levels:["student"],children:"StudentDash"});export{e as default};
//# sourceMappingURL=StudentDash-BA1Cw5WU.js.map
