import{j as t,h as a}from"./index-uqXiPZaM.js";import"./vendor-DTs43g_X.js";const e=()=>t.jsx(a,{title:"Daftar Mata Pelajaran",levels:["student"],children:"StudentLms"});export{e as default};
//# sourceMappingURL=StudentLms-Cwgl7u8N.js.map
