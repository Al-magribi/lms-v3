import{j as i,B as s,c9 as a}from"./index-uqXiPZaM.js";import"./vendor-DTs43g_X.js";const e=({onClick:e,disabled:o})=>i.jsx(s,{type:"primary",size:"medium",icon:i.jsx(a,{}),onClick:e,disabled:o,children:"Tambah"});export{e as A};
//# sourceMappingURL=Add-ClBUWLqP.js.map
